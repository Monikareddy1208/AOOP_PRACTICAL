package bank;

public class Main {
    public static void main(String[] args) {
        // Creating an account with initial balance $1000
        Account account = new Account(101, 1000.0);

        // Creating threads using Runnable interface
        Thread t1 = new Thread(new TransactionRunnable(account, 500, true), "Thread-Runnable-1");
        Thread t2 = new Thread(new TransactionRunnable(account, 200, false), "Thread-Runnable-2");
        
        // Creating threads by extending Thread class
        Thread t3 = new TransactionThread(account, 300, true);
        t3.setName("Thread-ThreadClass-1");

        Thread t4 = new TransactionThread(account, 700, false);
        t4.setName("Thread-ThreadClass-2");

        // Starting all threads
        t1.start();
        t2.start();
        t3.start();
        t4.start();

        // Ensuring all threads complete execution before checking the final balance
        try {
            t1.join();
            t2.join();
            t3.join();
            t4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Display final balance
        System.out.println("\nFinal Account Balance: $" + account.getBalance());
    }
}
