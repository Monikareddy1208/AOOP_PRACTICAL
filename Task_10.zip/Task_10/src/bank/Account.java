package bank;

public class Account {
    private int accountNumber;
    private double balance;

    // Constructor
    public Account(int accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }

    // Synchronized deposit method to ensure thread safety
    public synchronized void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println(Thread.currentThread().getName() + " deposited $" + amount + ". New Balance: $" + balance);
        }
    }

    // Synchronized withdraw method to ensure thread safety
    public synchronized void withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            System.out.println(Thread.currentThread().getName() + " withdrew $" + amount + ". New Balance: $" + balance);
        } else {
            System.out.println(Thread.currentThread().getName() + " attempted to withdraw $" + amount + " but insufficient balance.");
        }
    }

    // Method to get current balance
    public double getBalance() {
        return balance;
    }
}
