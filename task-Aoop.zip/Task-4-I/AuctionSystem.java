import java.util.ArrayList;
import java.util.List;

// Enum for auction events
enum AuctionEvent {
    ITEM_AVAILABLE, BIDDING_START, BIDDING_END
}

// Observer Interface
interface Observer {
    void update(AuctionEvent event, String message);
}

// Auction (Subject/Observable)
class Auction {
    private List<Observer> observers = new ArrayList<>();
    private String itemName;

    // Attach an observer
    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    // Detach an observer
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    // Notify all observers about an event
    public void notifyObservers(AuctionEvent event, String message) {
        for (Observer observer : observers) {
            observer.update(event, message);
        }
    }

    // Set the auction item
    public void setItem(String itemName) {
        this.itemName = itemName;
    }

    public String getItem() {
        return itemName;
    }
}

// Bidder (Observer)
class Bidder implements Observer {
    private String name;

    public Bidder(String name) {
        this.name = name;
    }

    @Override
    public void update(AuctionEvent event, String message) {
        System.out.println(name + " received notification: " + event + " - " + message);
    }
}

// Auction Process (Template Method)
abstract class AuctionProcess {

    // Template method to run the auction process
    public final void runAuction(Auction auction) {
        notifyItemAvailable(auction);
        startBidding(auction);
        endBidding(auction);
    }

    // Default implementation of auction steps
    private void notifyItemAvailable(Auction auction) {
        auction.notifyObservers(AuctionEvent.ITEM_AVAILABLE, "Item " + auction.getItem() + " is now available.");
    }

    // This step may be customized by subclasses
    protected abstract void startBidding(Auction auction);

    // This step may be customized by subclasses
    protected abstract void endBidding(Auction auction);
}

// Standard Auction Process (Concrete Template)
class StandardAuctionProcess extends AuctionProcess {

    @Override
    protected void startBidding(Auction auction) {
        auction.notifyObservers(AuctionEvent.BIDDING_START, "Bidding has started for item " + auction.getItem());
    }

    @Override
    protected void endBidding(Auction auction) {
        auction.notifyObservers(AuctionEvent.BIDDING_END, "Bidding has ended for item " + auction.getItem());
    }
}

// Reserve Auction Process (Concrete Template)
class ReserveAuctionProcess extends AuctionProcess {
    private double reservePrice;
    private double currentBid;

    public ReserveAuctionProcess(double reservePrice) {
        this.reservePrice = reservePrice;
    }

    @Override
    protected void startBidding(Auction auction) {
        auction.notifyObservers(AuctionEvent.BIDDING_START, "Bidding has started for item " + auction.getItem() + " with reserve price: " + reservePrice);
    }

    @Override
    protected void endBidding(Auction auction) {
        if (currentBid >= reservePrice) {
            auction.notifyObservers(AuctionEvent.BIDDING_END, "Bidding has ended for item " + auction.getItem() + ". Item sold at " + currentBid);
        } else {
            auction.notifyObservers(AuctionEvent.BIDDING_END, "Bidding has ended for item " + auction.getItem() + ". Reserve price not met.");
        }
    }

    public void setCurrentBid(double currentBid) {
        this.currentBid = currentBid;
    }
}

// Main class to run the auction system
public class AuctionSystem {
    public static void main(String[] args) {
        // Create auction
        Auction auction = new Auction();
        auction.setItem("Vintage Car");

        // Create bidders
        Bidder bidder1 = new Bidder("Alice");
        Bidder bidder2 = new Bidder("Bob");

        // Subscribe bidders to auction
        auction.addObserver(bidder1);
        auction.addObserver(bidder2);

        // Create and run a standard auction process
        AuctionProcess standardAuction = new StandardAuctionProcess();
        standardAuction.runAuction(auction);

        // Create and run a reserve auction process
        ReserveAuctionProcess reserveAuction = new ReserveAuctionProcess(10000);
        reserveAuction.setCurrentBid(12000);
        reserveAuction.runAuction(auction);
    }
}
