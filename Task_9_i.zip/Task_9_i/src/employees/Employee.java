package employees;

public class Employee {
    private String name;
    private int age;
    private int experience;
    private double salary;
    
    // Constructor
    public Employee(String name, int age, int experience, double salary) {
        this.name = name;
        this.age = age;
        this.experience = experience;
        this.salary = salary;
    }

    // Getters
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public int getExperience() {
        return experience;
    }

    public double getSalary() {
        return salary;
    }

    // Method to calculate bonus
    public double calculateBonus() {
        return experience > 2 ? salary * 0.10 : 0; // 10% bonus if experience > 2 years
    }

    @Override
    public String toString() {
        return "Employee{" + "name='" + name + "', age=" + age + 
               ", experience=" + experience + " years, salary=" + salary + 
               ", bonus=" + calculateBonus() + "}";
    }
}
