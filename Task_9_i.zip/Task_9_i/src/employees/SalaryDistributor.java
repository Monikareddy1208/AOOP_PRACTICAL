package employees;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class SalaryDistributor {
    private List<Employee> employees;

    // Constructor
    public SalaryDistributor() {
        employees = new ArrayList<>();
    }

    // Add employees
    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    // Sort employees by experience in descending order
    public void sortEmployeesByExperience() {
        employees.sort(Comparator.comparingInt(Employee::getExperience).reversed());
    }

    // Filter employees who are eligible for a bonus (experience > 2 years)
    public List<Employee> getEmployeesWithBonus() {
        Predicate<Employee> bonusPredicate = e -> e.getExperience() > 2;
        return employees.stream().filter(bonusPredicate).collect(Collectors.toList());
    }

    // Display all employees
    public void displayAllEmployees() {
        employees.forEach(System.out::println);
    }
}
