package employees;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        SalaryDistributor distributor = new SalaryDistributor();

        // Adding employees
        distributor.addEmployee(new Employee("Employee1", 30, 5, 50000));
        distributor.addEmployee(new Employee("Employee2", 28, 4, 45000));
        distributor.addEmployee(new Employee("Employee3", 26, 3, 40000));
        distributor.addEmployee(new Employee("Employee4", 24, 1, 35000));
        distributor.addEmployee(new Employee("Employee5", 22, 0, 30000));

        // Sorting employees by experience
        distributor.sortEmployeesByExperience();

        // Display sorted employees
        System.out.println("\nEmployees sorted by experience:");
        distributor.displayAllEmployees();

        // Get employees eligible for a bonus
        List<Employee> bonusEligibleEmployees = distributor.getEmployeesWithBonus();

        // Display employees getting a bonus
        System.out.println("\nEmployees receiving a bonus:");
        bonusEligibleEmployees.forEach(System.out::println);
    }
}
