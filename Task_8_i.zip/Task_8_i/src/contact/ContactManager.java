package contact;

import java.util.HashMap;
import java.util.Map;

public class ContactManager {
    private Map<String, String> contacts; // Map to store contacts (name → phone number)

    // Constructor
    public ContactManager() {
        contacts = new HashMap<>();
    }

    // Method to add a contact
    public void addContact(String name, String phoneNumber) {
        contacts.put(name, phoneNumber);
        System.out.println("Contact added: " + name + " - " + phoneNumber);
    }

    // Method to retrieve a contact's phone number
    public String getPhoneNumber(String name) {
        return contacts.getOrDefault(name, "Contact not found.");
    }

    // Method to remove a contact
    public void removeContact(String name) {
        if (contacts.containsKey(name)) {
            contacts.remove(name);
            System.out.println("Contact removed: " + name);
        } else {
            System.out.println("Contact not found.");
        }
    }

    // Method to display all contacts
    public void displayContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts available.");
        } else {
            System.out.println("Contact List:");
            for (Map.Entry<String, String> entry : contacts.entrySet()) {
                System.out.println(entry.getKey() + " - " + entry.getValue());
            }
        }
    }
}
