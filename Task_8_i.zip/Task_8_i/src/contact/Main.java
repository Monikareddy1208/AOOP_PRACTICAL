package contact;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ContactManager contactManager = new ContactManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== Contact Management System =====");
            System.out.println("1. Add Contact");
            System.out.println("2. Get Contact Number");
            System.out.println("3. Remove Contact");
            System.out.println("4. Display All Contacts");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Phone Number: ");
                    String phone = scanner.nextLine();
                    contactManager.addContact(name, phone);
                    break;

                case 2:
                    System.out.print("Enter Name to search: ");
                    name = scanner.nextLine();
                    System.out.println("Phone Number: " + contactManager.getPhoneNumber(name));
                    break;

                case 3:
                    System.out.print("Enter Name to remove: ");
                    name = scanner.nextLine();
                    contactManager.removeContact(name);
                    break;

                case 4:
                    contactManager.displayContacts();
                    break;

                case 5:
                    System.out.println("Exiting... Thank you!");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
