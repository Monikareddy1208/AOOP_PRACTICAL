package student;

import java.util.Scanner;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        StudentGradesManager gradesManager = new StudentGradesManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== Student Grades Management =====");
            System.out.println("1. Add Student Grade");
            System.out.println("2. Get Student Grades");
            System.out.println("3. Remove Student");
            System.out.println("4. Display All Student Grades");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Student ID: ");
                    int studentId = scanner.nextInt();
                    System.out.print("Enter Grade: ");
                    double grade = scanner.nextDouble();
                    gradesManager.addGrade(studentId, grade);
                    break;

                case 2:
                    System.out.print("Enter Student ID to retrieve grades: ");
                    studentId = scanner.nextInt();
                    Set<Double> grades = gradesManager.getGrades(studentId);
                    if (grades.isEmpty()) {
                        System.out.println("No grades found for Student ID: " + studentId);
                    } else {
                        System.out.println("Grades for Student ID " + studentId + ": " + grades);
                    }
                    break;

                case 3:
                    System.out.print("Enter Student ID to remove: ");
                    studentId = scanner.nextInt();
                    gradesManager.removeStudent(studentId);
                    break;

                case 4:
                    gradesManager.displayAllGrades();
                    break;

                case 5:
                    System.out.println("Exiting... Thank you!");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
