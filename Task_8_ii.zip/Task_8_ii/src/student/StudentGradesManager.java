package student;

import java.util.*;

public class StudentGradesManager {
    private Map<Integer, Set<Double>> studentGrades; // Map to store student grades

    // Constructor
    public StudentGradesManager() {
        studentGrades = new HashMap<>();
    }

    // Method to add a grade for a student
    public void addGrade(int studentId, double grade) {
        studentGrades.putIfAbsent(studentId, new HashSet<>());
        studentGrades.get(studentId).add(grade);
        System.out.println("Grade " + grade + " added for Student ID: " + studentId);
    }

    // Method to get grades of a student
    public Set<Double> getGrades(int studentId) {
        return studentGrades.getOrDefault(studentId, Collections.emptySet());
    }

    // Method to remove a student's grades
    public void removeStudent(int studentId) {
        if (studentGrades.containsKey(studentId)) {
            studentGrades.remove(studentId);
            System.out.println("Removed Student ID: " + studentId);
        } else {
            System.out.println("Student ID " + studentId + " not found.");
        }
    }

    // Method to display all students and their grades
    public void displayAllGrades() {
        if (studentGrades.isEmpty()) {
            System.out.println("No student grades available.");
        } else {
            System.out.println("\n===== Student Grades =====");
            for (Map.Entry<Integer, Set<Double>> entry : studentGrades.entrySet()) {
                System.out.println("Student ID: " + entry.getKey() + " → Grades: " + entry.getValue());
            }
        }
    }
}
