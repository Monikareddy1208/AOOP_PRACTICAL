package employees;

import java.util.List;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        EmployeeOperations operations = new EmployeeOperations();

        // Adding employees
        operations.addEmployee(new Employee("Alice", 30, "IT", 70000));
        operations.addEmployee(new Employee("Bob", 28, "HR", 50000));
        operations.addEmployee(new Employee("Charlie", 35, "Finance", 80000));
        operations.addEmployee(new Employee("David", 40, "IT", 90000));
        operations.addEmployee(new Employee("Eve", 25, "HR", 55000));

        // 1️⃣ Filtering employees by department (IT)
        System.out.println("\nEmployees in IT Department:");
        List<Employee> itEmployees = operations.filterByDepartment("IT");
        itEmployees.forEach(System.out::println);

        // 2️⃣ Sorting employees by name
        System.out.println("\nEmployees sorted by name:");
        List<Employee> sortedEmployees = operations.sortByName();
        sortedEmployees.forEach(System.out::println);

        // 3️⃣ Finding employee with the highest salary
        Optional<Employee> highestPaidEmployee = operations.findHighestSalary();
        System.out.println("\nEmployee with Highest Salary:");
        highestPaidEmployee.ifPresent(System.out::println);

        // 4️⃣ Calculating average salary
        double avgSalary = operations.calculateAverageSalary();
        System.out.println("\nAverage Salary of Employees: " + avgSalary);
    }
}
