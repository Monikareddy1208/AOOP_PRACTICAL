package employees;

import java.util.*;
import java.util.stream.Collectors;

public class EmployeeOperations {
    private List<Employee> employees;

    // Constructor
    public EmployeeOperations() {
        employees = new ArrayList<>();
    }

    // Method to add employees
    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    // 1️⃣ Filtering employees by department
    public List<Employee> filterByDepartment(String department) {
        return employees.stream()
                        .filter(e -> e.getDepartment().equalsIgnoreCase(department))
                        .collect(Collectors.toList());
    }

    // 2️⃣ Sorting employees by name
    public List<Employee> sortByName() {
        return employees.stream()
                        .sorted(Comparator.comparing(Employee::getName))
                        .collect(Collectors.toList());
    }

    // 3️⃣ Finding employee with highest salary
    public Optional<Employee> findHighestSalary() {
        return employees.stream()
                        .max(Comparator.comparing(Employee::getSalary));
    }

    // 4️⃣ Calculating average salary
    public double calculateAverageSalary() {
        return employees.stream()
                        .mapToDouble(Employee::getSalary)
                        .average()
                        .orElse(0.0);
    }
}
